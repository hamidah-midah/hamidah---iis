<footer class="footer">
    <p class="footer-title">SMK MIFTAHUL KHAIR</p>
    <p class="footer-text">
        &copy; <?= date('Y') ?> manajemen siswa. semua hak dilindungi.
    </p>
</footer>
</body>
</html>