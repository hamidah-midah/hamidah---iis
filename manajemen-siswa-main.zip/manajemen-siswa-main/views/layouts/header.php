<?php
$currentpage = basename($_SERVER['PHP_SELF']);
$isidaftar = in_array($currentpage, ['index.php','student.php', 'edit.php']); 
$isitambah = $currentpage === 'create.php';
?>

<!DOCTYPE html>
<html lang="id">                                                                        
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>manajemen siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <a href="index.php" class="navbar-brand">
                 <span class="brand-title">SMK MIFTAHUL KHAIR</span>
                 <span class="brand-sub">manajemen siswa</span>
        </a>
    <div class="navbar-menu">
        <a href="index.php" class="<?= $isidaftar ? 'active':''?>">daftar siswa</a>
        <a href="create.php" class="<?= $isitambah ? 'active' : ''?>">+ tambah siswa</a>
        <a href="logout.php" class="logout" onclinck="return confirm('yakin ingin keluar?')">
        lagout (<?= htmlspecialchars($_SESSION['username'] ?? '')?>)
        </a>
    </div>
</nav>
