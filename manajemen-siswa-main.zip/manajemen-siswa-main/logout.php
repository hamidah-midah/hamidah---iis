<?php

require __DIR__. '/config/auth.php';

$_SESSION = [];
session_destroy();

header('location: login.php');
exit;