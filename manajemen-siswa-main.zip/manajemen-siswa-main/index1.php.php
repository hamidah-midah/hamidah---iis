<?php

require 'config/database.php';
require __DIR__ . '/models/student.php';
require __DIR__ . '/controllers/studentcontroller.php';

// create an instance of the student model
$studentmodel = new student($pdo);

$controller = new studentcontroller($studentmodel);

$controller->index();

?>