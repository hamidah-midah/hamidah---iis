<?php
require __DIR__ . '/config/database.php';

if (!empty($_SESSion['user_id'])) {
    header('location: index.php');
    exit;
}
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header('location: index.php');
        exit;
         
       
}
$error = 'username atau password salah.';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login - manajemen siswa</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background:linear-gradient(135deg, #0003c9, #2563eb);
            font-family: "segoe UI", Arial, sans-serif;
        }

        .login-card {
            width: 100%;
            max-width: 380px;
            background: #FFFFFF;
            padding: 32px;
            border-radius: 14px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25);
        }
          .login-card h1 {
            margin: 0;
            text-align: center;
            font-size: 20px;
            color: #0027a8;;
        }
        .login-card .sub {
            text-align: center;
            margin: 4px 0 24px;
            font-size: 13px;
            color: #6b7280;
        }
        .login-card label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 6px;
        }
        .login-card input {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 16px;
            border: 1px solid #252525;
            border-radius: 8px;
            font-size: 14px;

        }
        .login-card input:focus {
            outline: none;
            border-color: #143885;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.2);
        }
        .login-card button { 
            width: 100%;
            padding: 11px;
            border: none; 
            border-radius: 8px;
            background: #0d22db;
            color: #ffffff;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;

        }
        .login-card button:hover {
            background: #252525;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 13px;
        } 
</style>

</head>
<body>

        <div class="login-card">
        <h1>SMK MIFTAHUL KHAIR</h1>
        <p class="sub">login Manajemen Siswa</p>
        <?php if ($error): ?>
 <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
 <form method="POST" action="login.php">
                <labe for="username">username</label>
                <input type="text" id="username" name="username" required autofocus>
                <label for="password">password</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">login</button>
        </form>
    </div>
</body>
</html>