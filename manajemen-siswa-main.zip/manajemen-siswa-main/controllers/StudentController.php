<?php

class StudentController
{
    private Student $studentModel;

    public function __construct(Student $studentModel)
    {
        $this->studentModel = $studentModel;
    }

    public function index()
    {
        $students = $this->studentModel->getAll();

        // Ambil notifikasi (flash message) sekali saja, lalu hapus dari session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);

        require __DIR__ . '/../views/students/index.php';
    }

    public function show($id)
    {
        $student = $this->studentModel->find($id);

    if (!$student) {
            echo "Data siswa tidak ditemukan.";
            exit;
    if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);
        }

        // Ambil notifikasi (flash message) sekali saja, lalu hapus dari session
    if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);

        require __DIR__ . '/../views/students/show.php';
    }

    public function edit($id)
    {
        $student = $this->studentModel->find($id);
        if (!$student) {
            echo "Data siswa tidak ditemukan.";
            exit;
        }
        require __DIR__ . '/../views/students/edit.php';
    }

    public function create()
    {
        require __DIR__ . '/../views/students/create.php';
    }

    public function store()
    {
        $data = [
            'nis' => $_POST['nis'],
            'name' => $_POST['name'],
            'gender' => $_POST['gender'],
            'class_name' => $_POST['class_name'],
            'major' => $_POST['major'],
            'birth_place' => $_POST['birth_place'],
            'birth_date' => $_POST['birth_date'],
        ];

        $this->studentModel->create($data);

        // Simpan pesan sukses, lalu arahkan ke daftar siswa
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['success'] = 'Data siswa berhasil ditambahkan.';

        header('Location: index.php');
        exit;
    }

    public function delete($id)
    {
        $this->studentModel->delete($id);
        header('Location: index.php');
        exit;
    }

    public function update($id)
    {
        $data = [
            'nis' => $_POST['nis'],
            'name' => $_POST['name'],
            'gender' => $_POST['gender'],
            'class_name' => $_POST['class_name'],
            'major' => $_POST['major'],
            'birth_place' => $_POST['birth_place'],
            'birth_date' => $_POST['birth_date'],
        ];
        $this->studentModel->update($id, $data);

    if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['success'] = 'Data siswa berhasil dihapus.';

        // Simpan pesan sukses, lalu arahkan ke halaman detail siswa
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['success'] = 'Data siswa berhasil diupdate.';

        header('Location: student.php?id=' . urlencode($id));
        exit;
    }

}