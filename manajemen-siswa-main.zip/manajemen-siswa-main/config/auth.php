<?php
if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $halamanBebas = ['login.php', 'logout.php', 'buat_admin.php'];
        $halamansaatini = basename($_SERVER['PHP_SELF']);

        if (!in_array($halamansaatini, $halamanBebas) && empty($_SESSION['user_id'])) {
            header('location: login.php');
            exit;
        }